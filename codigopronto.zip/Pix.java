package com.mycompany.pizzaria;

public class Pix {
    
    private String chave;

    public String getChave() {
        return chave;
    }

    public void setChave(String chave) {
        this.chave = chave;
    }
    
    public String toString() {
        return "Chave PIX: " + this.chave;
    }
    
}
